
import math
import time



question = input("Enter a yes/no question: ")
question1 = input("Did you recently do domething behind some else's back?(type yes or no all lowercase).")

if question1 == "yes":
        print("Your fortune is okay but not great. It all depends how much you did!")
else:
        print("Your fortune is good!")